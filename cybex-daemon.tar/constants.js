"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EVENT_ON_NEW_HISTORY = Symbol();
